/** 真实家目录（不读 $HOME：测试 / 隔离实例会改写它） */
export declare function realHomeDir(): string;
/** dev 根目录（`DIY_DEV_HOME` 可覆盖；缺省 `~/.diy/dev`） */
export declare function devRoot(env?: NodeJS.ProcessEnv): string;
/** 实例注册表目录（`DIY_INSTANCE_REGISTRY` 可覆盖，测试隔离用）；缺省 `<devRoot>/apps` */
export declare function registryDir(env?: NodeJS.ProcessEnv): string;
/** 旧位置（一次性搬迁的来源）：`~/.diy-instances` */
export declare function legacyRegistryDir(env?: NodeJS.ProcessEnv): string;
/** 确保注册表目录存在（写侧调用） */
export declare function ensureRegistryDir(env?: NodeJS.ProcessEnv): string;
/**
 * 把旧目录里的记录搬到新目录（一次性、幂等）。
 *
 * `.json` 文件按 pid 命名，新目录已有同名文件时**不覆盖**（新目录一定更新）。
 * 搬完旧目录即删（空目录也删）——避免下次再扫一遍。
 */
export declare function migrateLegacyRegistry(env?: NodeJS.ProcessEnv): {
    moved: number;
    skipped: number;
    from: string;
    to: string;
};
